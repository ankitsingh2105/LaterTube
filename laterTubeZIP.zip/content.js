console.log("YouTube Video Saver is running...");


function getCurrentDateAndTime() {
    const now = new Date();
    
    // Extract day, month, and year
    const day = String(now.getDate()).padStart(2, '0'); // Add leading zero if needed
    const month = String(now.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
    const year = now.getFullYear();
    
    // Construct the date in dd/mm/yyyy format
    const formattedDate = `${day}/${month}/${year}`;
    
    // Extract time and convert to 12-hour format
    let hours = now.getHours();
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const amPm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12; // Convert 0 to 12 for midnight
    
    // Construct the time
    const formattedTime = `${hours}:${minutes}:${seconds} ${amPm}`;
    
    return { date: formattedDate, time: formattedTime };
}


const addSaveButtonToTitle = () => {
    console.log("Attempting to add Save button...");
    const titleContainer = document.querySelector("#title.ytd-watch-metadata h1");

    if (titleContainer && !titleContainer.querySelector(".save-btn")) {
        console.log("Title container found. Adding Save button...");
        const saveBtn = document.createElement("button");
        saveBtn.innerText = "Watch Later";
        saveBtn.classList.add("save-btn");
        saveBtn.style.cssText =
            "margin-left: 10px; cursor: pointer; font-weight: bolder; border-radius: 18px; background: rgba(255, 255, 255, 0.1); border: none; padding: 5px 15px; color: white;";

        titleContainer.appendChild(saveBtn);

        saveBtn.addEventListener("click", () => {
            console.log("Save button clicked.");
            const title = titleContainer.innerText.trim();
            const url = window.location.href;

            // Extract video ID for thumbnail
            const videoID = new URL(url).searchParams.get("v");
            const thumbnail = videoID
                ? `https://i.ytimg.com/vi/${videoID}/maxresdefault.jpg`
                : "";


            try {
                chrome.storage.local.get(["savedVideos"], (data) => {
                    if (chrome.runtime.lastError) {
                        console.error("Error accessing storage:", chrome.runtime.lastError);
                        return;
                    }

                    const savedVideos = data.savedVideos || [];

                    const isAlreadySaved = savedVideos.some((video) => video.url === url);
                    if (isAlreadySaved) {
                        alert("This video is already saved.");
                        return;
                    }
                    const { date, time } = getCurrentDateAndTime();
                    savedVideos.push({ title, url, thumbnail, tag : "", time_added : ""  });
                    chrome.storage.local.set({ savedVideos }, () => {
                        if (chrome.runtime.lastError) {
                            console.error("Error saving video:", chrome.runtime.lastError);
                        } else {
                            alert("Video saved!");
                            console.log("Video saved successfully.");
                        }
                    });
                });
            } catch (error) {
                console.error("Error in Save button logic:", error);
            }
        });
    }
};

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", addSaveButtonToTitle);
} else {
    addSaveButtonToTitle();
}

const observer = new MutationObserver(() => {
    addSaveButtonToTitle();
});

observer.observe(document.body, { childList: true, subtree: true });

