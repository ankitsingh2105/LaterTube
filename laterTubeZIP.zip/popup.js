const videoList = document.getElementById('video-list');

const renderSavedVideos = (savedVideos) => {
    videoList.innerHTML = ''; // Clear the list before rendering
    savedVideos.forEach((video, index) => {
        const listItem = document.createElement('li');
        const videoLink = document.createElement('a');
        const thumbnail = document.createElement('img');
        const removeButton = document.createElement('button');

        const card = document.createElement("main");
        const div1 = document.createElement("div");
        const div2 = document.createElement("div");
        const endLine = document.createElement("br");

        videoLink.href = video.url;
        videoLink.target = '_blank';
        videoLink.textContent = video.title;

        thumbnail.src = video.thumbnail;

        removeButton.textContent = 'Remove';
        removeButton.className = 'remove-btn';
        removeButton.addEventListener('click', () => {
            savedVideos.splice(index, 1);
            chrome.storage.local.set({ savedVideos }, () => {
                if (chrome.runtime.lastError) {
                    console.error('Error removing video:', chrome.runtime.lastError);
                } else {
                    renderSavedVideos(savedVideos); 
                }
            });
        });

        div1.appendChild(thumbnail);
        div2.appendChild(videoLink);
        div2.appendChild(endLine);
        div2.appendChild(removeButton);

        card.appendChild(div1);
        card.appendChild(div2);

        listItem.appendChild(card);

        videoList.appendChild(listItem);
    });
};

// Fetch saved videos from storage
chrome.storage.local.get(['savedVideos'], (data) => {
    if (chrome.runtime.lastError) {
        console.error('Error accessing storage:', chrome.runtime.lastError);
        return;
    }

    const savedVideos = data.savedVideos || [];
    renderSavedVideos(savedVideos);
});
